<?php
require_once ('utility/db.class.php');

$HOST = 'localhost';
$USERNAME = 'socialNetwork';
$PASSWORD = '1234';
$DBNAME = 'social network';

$conn = new Database ($HOST, $USERNAME,$PASSWORD,$DBNAME);

